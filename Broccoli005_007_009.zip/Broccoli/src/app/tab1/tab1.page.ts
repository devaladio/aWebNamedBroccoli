import { Component } from '@angular/core';

@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss']
})
export class Tab1Page {
  slideOpts = {
    slidesPerView: 2.2

 }
  items=[
    {name:"Sayur"},
    {name:"Buah"},
    {name:"Junkfood"}
  ]
  sayur=[
    {name:"Broccoli"},
    {name:"Tomato"},
  ]
  sayur2=[
    {name:"Cabbage"},
    {name:"Carrot"},
  ]

  //gambar=[
  //  {name:"Broccoli.png"}
 // ]
  constructor() {}
}
